package com.example.be_shopbangiay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeShopbangiayApplicationTests {

	@Test
	void contextLoads() {
	}

}
